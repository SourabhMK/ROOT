/* tslint:disable */
require("./RoomFilters.module.css");
const styles = {
  roomFilters: 'roomFilters_cf60162f',
  dropDown: 'dropDown_cf60162f',
  title: 'title_cf60162f',
  subTitle: 'subTitle_cf60162f',
  button: 'button_cf60162f',
  label: 'label_cf60162f'
};

export default styles;
/* tslint:enable */