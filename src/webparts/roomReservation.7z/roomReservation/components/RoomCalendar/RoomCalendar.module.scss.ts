/* tslint:disable */
require("./RoomCalendar.module.css");
const styles = {
  roomCalendar: 'roomCalendar_1ade2164'
};

export default styles;
/* tslint:enable */