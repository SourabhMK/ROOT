export interface IRoomCalendarProps {
    description: string; 
    context:any;
    locationId: number;
    areaId:number;
    buildingId: number;
    sizeId: number;
}