
export interface IRoomCalendarStates {
    events: CalendarEventInfo[];
    selectedEvent: CalendarEventInfo;
    errorMessage: string;
}

export interface CalendarEventInfo {
    title:string;
    date: Date;
}