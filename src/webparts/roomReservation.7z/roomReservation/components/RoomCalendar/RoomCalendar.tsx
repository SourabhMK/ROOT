import * as React from 'react';
import styles from './RoomCalendar.module.scss';
import { IRoomCalendarProps } from './IRoomCalendarProps';
import { IRoomCalendarStates } from './IRoomCalendarState';
import  RoomService  from '../../roomService';

export default class RoomCalendar extends React.Component<IRoomCalendarProps, IRoomCalendarStates> {
    constructor(props:IRoomCalendarProps, state:IRoomCalendarStates) { 
        super(props);
        this.state = {
            events: [],
            selectedEvent: null,
            errorMessage : ""
        };
    }

    public componentDidMount() : void {
        this. _getRoomEventsByPara(this.props.locationId, this.props.areaId, this.props.buildingId, this.props.sizeId);
    }

    private _getRoomEventsByPara(locationId:number, areaId:number, buildingId:number, sizeId:number) {
        //let service = new RoomService(this.props.context);
         //service.GetRoomImagesBySize(sizeId).then(data => {
         //    console.log("data : " + data);
         //   debugger;
            // this.setState({
            //     imagePaths : data
            // });
         //});
    }

    public render(): React.ReactElement<IRoomCalendarProps> {
        return (
            <div>Calendar here</div>
        );
    }
}
