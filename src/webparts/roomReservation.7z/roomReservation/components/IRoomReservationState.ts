export interface IRoomReservationStates {
    locationId: number;
    areaId:number;
    buildingId: number;
    sizeId: number;
}
