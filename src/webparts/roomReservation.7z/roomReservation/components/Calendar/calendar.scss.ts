/* tslint:disable */
require("./calendar.css");
const styles = {

};

export default styles;
/* tslint:enable */