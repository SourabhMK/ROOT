/* tslint:disable */
require("./Calendar.module.css");
const styles = {
  themeDark: '"[theme:themePrimary, default: #0078d4]"',
  eventStyleSetter: 'eventStyleSetter_75534801',
  dayPropGetter: 'dayPropGetter_75534801',
  Documentcard: 'Documentcard_75534801',
  previewEventIcon: 'previewEventIcon_75534801',
  locationIcon: 'locationIcon_75534801',
  location: 'location_75534801',
  DocumentCardDetails: 'DocumentCardDetails_75534801',
  eventStyle: 'eventStyle_75534801',
  DocumentCardTitle: 'DocumentCardTitle_75534801',
  DocumentCardTitleTime: 'DocumentCardTitleTime_75534801',
  calendar: 'calendar_75534801',
  container: 'container_75534801',
  plainCard: 'plainCard_75534801',
  eventTitle: 'eventTitle_75534801',
  row: 'row_75534801',
  column: 'column_75534801',
  'ms-Grid': 'ms-Grid_75534801',
  title: 'title_75534801',
  subTitle: 'subTitle_75534801',
  description: 'description_75534801',
  button: 'button_75534801',
  label: 'label_75534801'
};

export default styles;
/* tslint:enable */