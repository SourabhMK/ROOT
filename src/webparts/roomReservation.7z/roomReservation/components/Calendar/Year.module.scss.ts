/* tslint:disable */
require("./Year.module.css");
const styles = {
  year: 'year_d7629523',
  month: 'month_d7629523',
  monthName: 'monthName_d7629523',
  day: 'day_d7629523',
  date: 'date_d7629523',
  inMonth: 'inMonth_d7629523',
  today: 'today_d7629523',
  prevMonth: 'prevMonth_d7629523',
  nextMonth: 'nextMonth_d7629523'
};

export default styles;
/* tslint:enable */