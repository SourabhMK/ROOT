/* tslint:disable */
require("./RoomReservation.module.css");
const styles = {
  roomReservation: 'roomReservation_3045c7de',
  container: 'container_3045c7de',
  row: 'row_3045c7de',
  column: 'column_3045c7de',
  'ms-Grid': 'ms-Grid_3045c7de',
  title: 'title_3045c7de',
  subTitle: 'subTitle_3045c7de',
  description: 'description_3045c7de',
  button: 'button_3045c7de',
  label: 'label_3045c7de'
};

export default styles;
/* tslint:enable */