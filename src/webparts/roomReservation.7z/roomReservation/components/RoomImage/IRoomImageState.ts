
export interface IRoomImageStates {
    selectedImage: string;
    imagePaths: string[];
    errorMessage: string;
}