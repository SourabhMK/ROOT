/* tslint:disable */
require("./RoomImage.module.css");
const styles = {
  roomFilters: 'roomFilters_a2d9407a',
  dropDown: 'dropDown_a2d9407a',
  title: 'title_a2d9407a',
  subTitle: 'subTitle_a2d9407a',
  button: 'button_a2d9407a',
  label: 'label_a2d9407a',
  selected: 'selected_a2d9407a'
};

export default styles;
/* tslint:enable */