export interface IRoomImageProps {
    description: string; 
    context:any;
    locationId: number;
    areaId:number;
    buildingId: number;
    sizeId: number;
}